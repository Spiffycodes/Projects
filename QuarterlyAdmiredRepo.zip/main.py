# This line adds the input
def add(x, y):
    return x + y

# This line divides the input
def divide(x, y):
    return x / y


# This line multiplies the input
def multiply(x, y):
    return x * y

# This line subtracts the input
def subtract(x, y):
    return x - y

print("What are you trying to do?")
print("1.Add")
print("2.Subtract")
print("3.Multiply")
print("4.Divide")

while True:
    # This will ask the user to pick the operation
    choice = input("Enter choice(1/2/3/4): ")

    # This will make sure the user picks one of the operations
    if choice in ('1', '2', '3', '4'):
        num1 = float(input("Enter first number: "))
        num2 = float(input("Enter second number: "))

        if choice == '1':
            print(num1, "+", num2, "=", add(num1, num2))

        elif choice == '2':
            print(num1, "-", num2, "=", subtract(num1, num2))

        elif choice == '3':
            print(num1, "*", num2, "=", multiply(num1, num2))

        elif choice == '4':
            print(num1, "/", num2, "=", divide(num1, num2))
        break
    else:
        print("I said pick a number from 1-4")