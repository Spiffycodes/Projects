a= (input("Enter side A: "))
b= (input("Enter side B:"))
c= (input("Enter side C:"))
d= (input("Enter side D:"))
e= (input("Enter side E: "))
a1 = float(a)
b1 = float(b)
c1 = float(c)
d1 = float(d)
e1 = float(e)



AB = (a1 * b1)
DBE = (d1 - b1 - e1)
AC = (a1 - c1)
DBEAC = (DBE * AC)
ABDBEAC = (AB + DBEAC)
EAC = ((1/2) * (e1) * (a1 - c1))
All= (AB+DBEAC + EAC)


print("Room Area:", All)